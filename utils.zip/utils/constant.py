# utils/constant.py

model_dimension = 512
number_of_heads = 8
src_vocab_size = 10000
trg_vocab_size = 10000
number_of_layers = 6
dropout_probability = 0.1